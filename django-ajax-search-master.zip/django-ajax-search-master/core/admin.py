from django.contrib import admin
from core.models import Artist, MusicRelease

# Register your models here.

admin.site.register(Artist)
admin.site.register(MusicRelease)
