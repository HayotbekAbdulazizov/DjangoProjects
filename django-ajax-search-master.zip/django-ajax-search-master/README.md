### Incremental (as-you-type) search with Django and Ajax

source code for my tutorial at https://openfolder.sh/django-tutorial-as-you-type-search-with-ajax

#### Installing

1. Clone this repository
2. Inside the root folder, run `pipenv install` to install dependencies
3. Run `pipenv shell` to start working in the virtual environment
4. Before running `./manage.py runserver`, make sure you apply the database migrations (`./manage.py migrate`)
