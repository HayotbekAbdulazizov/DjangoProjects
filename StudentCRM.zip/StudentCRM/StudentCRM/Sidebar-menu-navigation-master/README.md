# Sidebar menu navigation
## Suscribete al canal para mas contenido
[Suscribete](https://www.youtube.com/c/Bedimcode)
